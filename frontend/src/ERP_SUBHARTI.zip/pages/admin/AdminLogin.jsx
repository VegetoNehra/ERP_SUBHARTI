import { Navigate, useNavigate } from "react-router-dom";
import { useState } from "react";
import axios from "axios";

function AdminLogin() {
  const navigate = useNavigate();

  const user = JSON.parse(localStorage.getItem("user"));

  if (user) {
    const redirectPath =
      user.role === "admin"
        ? "/admin/dashboard"
        : "/student/dashboard";

    return <Navigate to={redirectPath} />;
  }

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  async function handleLogin(e) {
    e.preventDefault();

    setError("");

    if (!username.trim() || !password.trim()) {
      setError("Please enter username and password");
      return;
    }

    try {
      const response = await axios.post(
        "http://localhost:5000/api/auth/login",
        {
          username,
          password,
          role: "admin",
        }
      );

      localStorage.setItem(
        "user",
        JSON.stringify(response.data.user)
      );

      navigate("/admin/dashboard");
    } catch (error) {
      setError(
        error.response?.data?.message ||
        "Login failed"
      );
    }
  }
  return (
    <div className="min-h-[calc(100vh-96px)] bg-slate-100 flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-3xl bg-white rounded-3xl overflow-hidden shadow-2xl border border-slate-200">

        {/* Header */}
        <div className="bg-blue-900 px-12 py-10 relative overflow-hidden">

          {/* Decorative circles */}
          <div className="absolute right-0 top-0 h-52 w-52 rounded-full bg-white/5 translate-x-16 -translate-y-8"></div>
          <div className="absolute right-24 top-0 h-72 w-72 rounded-full bg-white/5"></div>

          <div className="relative z-10">
            <h2 className="text-5xl font-bold text-white">
              Admin Login
            </h2>

            <p className="mt-3 text-xl text-slate-300">
              Enter your credentials to access the ERP portal
            </p>
          </div>
        </div>

        {/* Form Body */}
        <div className="p-14">

          <form onSubmit={handleLogin} className="space-y-8">

            {/* ID */}
            <div>
              <label className="block text-2xl font-semibold text-slate-800 mb-4">
                Admin ID
              </label>

              <input
                type="text"
                placeholder="e.g. SU2024001"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-6 py-5 text-xl border-2 border-slate-200 rounded-2xl outline-none focus:border-gray-900 focus:ring-2 focus:ring-gray-900/20 transition"
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-2xl font-semibold text-slate-800 mb-4">
                Password
              </label>

              <input
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-6 py-5 text-xl border-2 border-slate-200 rounded-2xl outline-none focus:border-blue-900 focus:ring-2 focus:ring-blue-900/20 transition"
              />
            </div>

            {/* Forgot Password */}
            <div className="flex justify-end">
              <button
                type="button"
                className="text-blue-700 text-lg font-medium hover:text-blue-900 transition"
              >
                Forgot password?
              </button>
            </div>
            {error && (<p className="text-red-600 font-medium">{error} </p>)}


            {/* Login Button */}
            <button
              type="submit"
              className="w-full bg-blue-950 hover:bg-blue-900 text-white text-2xl font-semibold py-5 rounded-2xl transition duration-200 shadow-md"
            >
              Access ERP Portal
            </button>

            {/* Footer */}
            <div className="text-center pt-4">
              <p className="text-slate-500 text-lg">
                Need help accessing your account?{" "}
                <span className="text-blue-700 font-semibold cursor-pointer hover:text-blue-900">
                  Contact ERP Administrator
                </span>
              </p>
            </div>

          </form>

        </div>
      </div>
    </div>
  );
}

export default AdminLogin;