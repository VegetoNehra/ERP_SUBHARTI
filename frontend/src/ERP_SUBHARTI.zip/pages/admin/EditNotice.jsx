import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const EditNotice = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [notice, setNotice] = useState({
    title: "",
    content: "",
  });

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchNotice = async () => {
      try {
        setLoading(true);
        setError("");
        const response = await axios.get(
          `http://localhost:5000/api/admin/notices/${id}`
        );
        setNotice(response.data.notice);
      } catch (error) {
        console.error("Error fetching notice:", error);
        setError("Failed to load notice. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchNotice();
    }
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNotice({
      ...notice,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!notice.title.trim() || !notice.content.trim()) {
      setError("Title and content cannot be empty");
      return;
    }

    try {
      setSubmitting(true);
      setError("");
      await axios.put(
        `http://localhost:5000/api/admin/notices/${id}`,
        notice
      );

      alert("Notice updated successfully!");
      navigate("/admin/dashboard");
    } catch (error) {
      console.error("Error updating notice:", error);
      setError("Failed to update notice. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-[calc(100vh-96px)] bg-slate-100 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-slate-300 border-t-[#0F2557] rounded-full animate-spin"></div>
          <p className="text-slate-500 text-lg">Loading Notice...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-96px)] bg-slate-100 flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-3xl bg-white rounded-3xl overflow-hidden shadow-2xl border border-slate-200">
        <div className="bg-[#0F2557] px-8 py-8">
          <h1 className="text-3xl font-bold text-white">Edit Notice</h1>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="p-8 flex flex-col gap-5">
            {error && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-md">
                <p className="text-red-700 text-sm">{error}</p>
              </div>
            )}

            <div>
              <label className="block mb-2 font-medium text-slate-700">
                Title
              </label>
              <input
                type="text"
                name="title"
                value={notice.title}
                onChange={handleChange}
                className="border border-gray-300 rounded-md p-3 w-full focus:outline-none focus:border-[#0F2557] focus:ring-2 focus:ring-[#0F2557]/20 transition"
                placeholder="Enter notice title"
                required
                disabled={submitting}
              />
            </div>

            <div>
              <label className="block mb-2 font-medium text-slate-700">
                Content
              </label>
              <textarea
                name="content"
                value={notice.content}
                onChange={handleChange}
                rows={8}
                className="border border-gray-300 rounded-md p-3 w-full resize-none focus:outline-none focus:border-[#0F2557] focus:ring-2 focus:ring-[#0F2557]/20 transition"
                placeholder="Enter notice content"
                required
                disabled={submitting}
              />
            </div>

            <div className="flex gap-3">
              <button
                type="submit"
                className="flex-1 bg-[#0F2557] text-white py-3 rounded-lg font-semibold hover:opacity-90 transition disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={submitting}
              >
                {submitting ? "Updating..." : "Update Notice"}
              </button>
              <button
                type="button"
                onClick={() => navigate("/admin/dashboard")}
                className="flex-1 border border-slate-300 py-3 rounded-lg font-semibold text-slate-700 hover:bg-slate-100 transition disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={submitting}
              >
                Cancel
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditNotice;
