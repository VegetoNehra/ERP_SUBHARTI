import { useEffect, useState } from "react";
import axios from "axios";

export default function ManageFaculty() {
  const [faculty, setFaculty] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const fetchFaculty  = async () => {
      try {
        const response = await axios.get(
          "http://localhost:5000/api/admin/manage-faculty"
        );

        setFaculty(response.data.faculty);
      } catch (error) {
        console.error(error);
      }
    };

    fetchFaculty();
  }, []);

  const filteredFaculty = faculty.filter(
    (facultyMember) =>
      facultyMember.name
        ?.toLowerCase()
        .includes(search.toLowerCase()) ||
      facultyMember.employee_id
        ?.toLowerCase()
        .includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto">

        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-[#0F2557]">
            Manage Faculty
          </h1>

          <p className="text-slate-500 mt-1">
            View all registered faculty members.
          </p>
        </div>

        {/* Search */}
        <div className="bg-white rounded-xl shadow-sm border p-4 mb-4">
          <input
            type="text"
            placeholder="Search by name or employee ID..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
          <div className="overflow-x-auto">

            <table className="w-full min-w-[1200px]">
              <thead className="bg-slate-100">
                <tr>
                  <th className="px-4 py-3 text-left">Employee ID</th>
                  <th className="px-4 py-3 text-left">Name</th>
                  <th className="px-4 py-3 text-left">Course</th>
                  <th className="px-4 py-3 text-left">Date of Birth</th>
                  <th className="px-4 py-3 text-left">Gender</th>
                  <th className="px-4 py-3 text-left">Branch</th>
                  <th className="px-4 py-3 text-left">Phone</th>
                  <th className="px-4 py-3 text-left">Email</th>
                </tr>
              </thead>

              <tbody>
                {filteredFaculty.map((facultyMember) => (
                  <tr
                    key={facultyMember.employee_id}
                    className="border-t hover:bg-slate-50"
                  >
                    <td className="px-4 py-3">
                      {facultyMember.employee_id}
                    </td>

                    <td className="px-4 py-3">
                      {facultyMember.name}
                    </td>

                    <td className="px-4 py-3">
                      {facultyMember.course}
                    </td>

                    <td className="px-4 py-3">
                      {facultyMember.dob
                        ? new Date(facultyMember.dob).toLocaleDateString("en-IN")
                        : "-"}
                    </td>

                    <td className="px-4 py-3">
                      {facultyMember.gender}
                    </td>

                    <td className="px-4 py-3">
                      {facultyMember.branch}
                    </td>

                    <td className="px-4 py-3">
                      {facultyMember.phone}
                    </td>

                    <td className="px-4 py-3">
                      {facultyMember.email}
                    </td>
                  </tr>
                ))}

                {filteredFaculty.length === 0 && (
                  <tr>
                    <td
                      colSpan="8"
                      className="text-center py-6 text-slate-500"
                    >
                      No faculty members found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>

          </div>
        </div>

      </div>
    </div>
  );
}