import { useState } from "react";
import { UserPlus, ArrowRight } from "lucide-react";
import axios from "axios";

export default function RegisterFaculty() {
  const [formData, setFormData] = useState({
    employeeId: "",
    name: "",
    email: "",
    phone: "",  
    dob: "",
    gender: "", 
    course: "",
    branch: "",
    });

  const branches = {
    btech: ["CSE", "IT", "AI & ML", "ECE", "Mechanical"],
    bca: ["General"],
    dental: ["BDS"],
    mbbs: ["General"],
  };

  function handleChange(e) {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  }

  async function handleSubmit(e) {
  e.preventDefault();

  try {

    const response = await axios.post(
      "http://localhost:5000/api/admin/register-faculty",
      formData
    );

    console.log(response.data);

    alert("Data sent successfully");

  } catch (error) {

    console.error(error);

    alert("Error sending data");

  }
}

  return (
    <div className="min-h-[calc(100vh-96px)] bg-slate-100 flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-3xl bg-white rounded-3xl overflow-hidden shadow-2xl border border-slate-200">

        {/* Header */}
        <div className="bg-[#0F2557] px-8 py-8">
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <UserPlus className="w-8 h-8" />
            Register Faculty
          </h1>

          <p className="text-slate-300 mt-2">
            Register a new faculty member in the ERP system.
          </p>
        </div>

        {/* Form */}
        <form
          onSubmit={handleSubmit}
          className="p-8 sm:p-10 space-y-10"
        >

          {/* Personal Information */}
          <section>
            <h2 className="text-lg font-bold text-slate-800 mb-5 border-b border-slate-200 pb-2">
              Personal Information
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">

              <InputField
                label="Full Name"
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="John Doe"
              />

              <InputField
                label="Email Address"
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="faculty@example.com"
              />

              <InputField
                label="Phone Number"
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="9876543210"
              />

              <InputField
              label="Date of Birth"
              type="date"
              name="dob"
              value={formData.dob}
              onChange={handleChange}
            />

            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-2">
                Gender
              </label>

              <select
                name="gender"
                value={formData.gender}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:ring-2 focus:ring-[#1E4DB7]/20 focus:border-[#1E4DB7] outline-none text-slate-700"
              >
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>

              <div></div>

            </div>
          </section>

          {/* Academic Information */}
          <section>
            <h2 className="text-lg font-bold text-slate-800 mb-5 border-b border-slate-200 pb-2">
              Academic Information
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">

              <InputField
                label="Employee ID"
                type="text"
                name="employeeId"
                value={formData.employeeId}
                onChange={handleChange}
                placeholder="230032010001"
              />

              

              {/* Course */}
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-2">
                  Course
                </label>

                <select
                  name="course"
                  value={formData.course}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:ring-2 focus:ring-[#1E4DB7]/20 focus:border-[#1E4DB7] outline-none"
                >
                  <option value="">Select Course</option>
                  <option value="B.Tech">B.Tech</option>
                  <option value="BCA">BCA</option>
                  <option value="Dental">Dental</option>
                  <option value="MBBS">MBBS</option>
                </select>
              </div>

              {/* Branch */}
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-2">
                  Branch
                </label>

                <select
                  name="branch"
                  value={formData.branch}
                  onChange={handleChange}
                  disabled={!formData.course}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:ring-2 focus:ring-[#1E4DB7]/20 focus:border-[#1E4DB7] outline-none disabled:opacity-50"
                >
                  <option value="">Select Branch</option>

                  {formData.course &&
                    branches[formData.course].map((branch) => (
                      <option
                        key={branch}
                        value={branch}
                      >
                        {branch}
                      </option>
                    ))}
                </select>
              </div>

             

            </div>
          </section>

          {/* Account Information */}
          <section>
            <h2 className="text-lg font-bold text-slate-800 mb-5 border-b border-slate-200 pb-2">
              Account Information
            </h2>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">

              <div>
                <p className="font-semibold text-slate-700">
                  Username
                </p>

                <p className="text-slate-500 text-sm">
                  EmployeeID will be used as the username.
                </p>
              </div>

              <div>
                <p className="font-semibold text-slate-700">
                  Password
                </p>

                <p className="text-slate-500 text-sm">
                  Password will be generated automatically by the system.
                </p>
              </div>

            </div>
          </section>

          {/* Submit */}
          <div className="pt-4 border-t border-slate-200">
            <button
              type="submit"
              className="w-full sm:w-auto px-8 py-3 bg-[#1E4DB7] hover:bg-[#0F2557] text-white font-semibold rounded-xl transition-all flex items-center justify-center gap-2"
            >
              Register Faculty
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </form>
      </div>
    </div>
  );
}

function InputField({
  label,
  type,
  name,
  value,
  onChange,
  placeholder,
}) {
  return (
    <div>
      <label className="block text-sm font-semibold text-slate-600 mb-2">
        {label}
      </label>

      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        required
        className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:ring-2 focus:ring-[#1E4DB7]/20 focus:border-[#1E4DB7] outline-none text-slate-700"
      />
    </div>
  );
}