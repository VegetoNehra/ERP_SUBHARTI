import { useState } from "react";
import { UserPlus, ArrowRight } from "lucide-react";
import axios from "axios";

export default function RegisterStudent() {
  const [formData, setFormData] = useState({
  enrollmentNo: "",
  name: "",
  fatherName: "",
  motherName: "",
  email: "",
  phone: "",
  dob: "",
  gender: "",
  course: "",
  branch: "",
  semester: "",
  class10: "",
  class12: "",
});

  const branches = {
    btech: ["CSE", "IT", "AI & ML", "ECE", "Mechanical"],
    bca: ["General"],
    dental: ["BDS"],
    mbbs: ["General"],
  };

  function handleChange(e) {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  }

  async function handleSubmit(e) {
  e.preventDefault();

  try {

    const response = await axios.post(
      "http://localhost:5000/api/admin/register-student",
      formData
    );

    console.log(response.data);

    alert("Data sent successfully");

  } catch (error) {

    console.error(error);

    alert("Error sending data");

  }
}

  return (
    <div className="min-h-[calc(100vh-96px)] bg-slate-100 flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-3xl bg-white rounded-3xl overflow-hidden shadow-2xl border border-slate-200">

        {/* Header */}
        <div className="bg-[#0F2557] px-8 py-8">
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <UserPlus className="w-8 h-8" />
            Register Student
          </h1>

          <p className="text-slate-300 mt-2">
            Register a new student in the ERP system.
          </p>
        </div>

        {/* Form */}
        <form
          onSubmit={handleSubmit}
          className="p-8 sm:p-10 space-y-10"
        >

          {/* Personal Information */}
          <section>
            <h2 className="text-lg font-bold text-slate-800 mb-5 border-b border-slate-200 pb-2">
              Personal Information
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">

              <InputField
                label="Full Name"
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="John Doe"
              />

              <InputField
                label="Email Address"
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="student@example.com"
              />

              <InputField
                label="Phone Number"
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="9876543210"
              />

              <InputField
              label="Date of Birth"
              type="date"
              name="dob"
              value={formData.dob}
              onChange={handleChange}
            />

            <div>
              <label className="block text-sm font-semibold text-slate-600 mb-2">
                Gender
              </label>

              <select
                name="gender"
                value={formData.gender}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:ring-2 focus:ring-[#1E4DB7]/20 focus:border-[#1E4DB7] outline-none text-slate-700"
              >
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>

              <div></div>

              <InputField
                label="Father's Name"
                type="text"
                name="fatherName"
                value={formData.fatherName}
                onChange={handleChange}
                placeholder="Enter father's name"
              />

              <InputField
                label="Mother's Name"
                type="text"
                name="motherName"
                value={formData.motherName}
                onChange={handleChange}
                placeholder="Enter mother's name"
              />

            </div>
          </section>

          {/* Academic Information */}
          <section>
            <h2 className="text-lg font-bold text-slate-800 mb-5 border-b border-slate-200 pb-2">
              Academic Information
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">

              <InputField
                label="Enrollment Number"
                type="text"
                name="enrollmentNo"
                value={formData.enrollmentNo}
                onChange={handleChange}
                placeholder="230032010001"
              />

              <InputField
                label="Semester"
                type="number"
                name="semester"
                value={formData.semester}
                onChange={handleChange}
                placeholder="1"
              />

              {/* Course */}
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-2">
                  Course
                </label>

                <select
                  name="course"
                  value={formData.course}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:ring-2 focus:ring-[#1E4DB7]/20 focus:border-[#1E4DB7] outline-none"
                >
                  <option value="">Select Course</option>
                  <option value="btech">B.Tech</option>
                  <option value="bca">BCA</option>
                  <option value="dental">Dental</option>
                  <option value="mbbs">MBBS</option>
                </select>
              </div>

              {/* Branch */}
              <div>
                <label className="block text-sm font-semibold text-slate-600 mb-2">
                  Branch
                </label>

                <select
                  name="branch"
                  value={formData.branch}
                  onChange={handleChange}
                  disabled={!formData.course}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:ring-2 focus:ring-[#1E4DB7]/20 focus:border-[#1E4DB7] outline-none disabled:opacity-50"
                >
                  <option value="">Select Branch</option>

                  {formData.course &&
                    branches[formData.course].map((branch) => (
                      <option
                        key={branch}
                        value={branch}
                      >
                        {branch}
                      </option>
                    ))}
                </select>
              </div>

              <InputField
                label="10th Percentage (%)"
                type="number"
                name="class10"
                value={formData.class10}
                onChange={handleChange}
                placeholder="88"
              />

              <InputField
                label="12th Percentage (%)"
                type="number"
                name="class12"
                value={formData.class12}
                onChange={handleChange}
                placeholder="84"
              />

            </div>
          </section>

          {/* Account Information */}
          <section>
            <h2 className="text-lg font-bold text-slate-800 mb-5 border-b border-slate-200 pb-2">
              Account Information
            </h2>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 space-y-4">

              <div>
                <p className="font-semibold text-slate-700">
                  Username
                </p>

                <p className="text-slate-500 text-sm">
                  Enrollment Number will be used as the username.
                </p>
              </div>

              <div>
                <p className="font-semibold text-slate-700">
                  Password
                </p>

                <p className="text-slate-500 text-sm">
                  Password will be generated automatically by the system.
                </p>
              </div>

            </div>
          </section>

          {/* Submit */}
          <div className="pt-4 border-t border-slate-200">
            <button
              type="submit"
              className="w-full sm:w-auto px-8 py-3 bg-[#1E4DB7] hover:bg-[#0F2557] text-white font-semibold rounded-xl transition-all flex items-center justify-center gap-2"
            >
              Register Student
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </form>
      </div>
    </div>
  );
}

function InputField({
  label,
  type,
  name,
  value,
  onChange,
  placeholder,
}) {
  return (
    <div>
      <label className="block text-sm font-semibold text-slate-600 mb-2">
        {label}
      </label>

      <input
        type={type}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        required
        className="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 focus:ring-2 focus:ring-[#1E4DB7]/20 focus:border-[#1E4DB7] outline-none text-slate-700"
      />
    </div>
  );
}