import { useEffect, useState } from "react";
import axios from "axios";

export default function ManageStudents() {
  const [students, setStudents] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const response = await axios.get(
          "http://localhost:5000/api/admin/manage-students"
        );

        setStudents(response.data.students);
      } catch (error) {
        console.error(error);
      }
    };

    fetchStudents();
  }, []);

  const filteredStudents = students.filter(
    (student) =>
      student.student_name
        ?.toLowerCase()
        .includes(search.toLowerCase()) ||
      student.enrollment_number
        ?.toLowerCase()
        .includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto">

        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-[#0F2557]">
            Manage Students
          </h1>

          <p className="text-slate-500 mt-1">
            View all registered students.
          </p>
        </div>

        {/* Search */}
        <div className="bg-white rounded-xl shadow-sm border p-4 mb-4">
          <input
            type="text"
            placeholder="Search by name or enrollment number..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* Table */}
        <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
          <div className="overflow-x-auto">

            <table className="w-full min-w-[1200px]">
              <thead className="bg-slate-100">
                <tr>
                  <th className="px-4 py-3 text-left">Enrollment No</th>
                  <th className="px-4 py-3 text-left">Student Name</th>
                  <th className="px-4 py-3 text-left">Father Name</th>
                  <th className="px-4 py-3 text-left">Mother Name</th>
                  <th className="px-4 py-3 text-left">Course</th>
                  <th className="px-4 py-3 text-left">Branch</th>
                  <th className="px-4 py-3 text-left">Semester</th>
                  <th className="px-4 py-3 text-left">Gender</th>
                  <th className="px-4 py-3 text-left">DOB</th>
                  <th className="px-4 py-3 text-left">Phone</th>
                  <th className="px-4 py-3 text-left">Email</th>
                </tr>
              </thead>

              <tbody>
                {filteredStudents.map((student) => (
                  <tr
                    key={student.enrollment_number}
                    className="border-t hover:bg-slate-50"
                  >
                    <td className="px-4 py-3">
                      {student.enrollment_number}
                    </td>

                    <td className="px-4 py-3">
                      {student.student_name}
                    </td>

                    <td className="px-4 py-3">
                      {student.father_name}
                    </td>

                    <td className="px-4 py-3">
                      {student.mother_name}
                    </td>

                    <td className="px-4 py-3">
                      {student.course}
                    </td>

                    <td className="px-4 py-3">
                      {student.branch}
                    </td>

                    <td className="px-4 py-3">
                      {student.semester}
                    </td>

                    <td className="px-4 py-3">
                      {student.gender}
                    </td>

                    <td className="px-4 py-3">
                      {student.dob
                        ? new Date(student.dob).toLocaleDateString(
                            "en-IN"
                          )
                        : "-"}
                    </td>

                    <td className="px-4 py-3">
                      {student.phone}
                    </td>

                    <td className="px-4 py-3">
                      {student.email}
                    </td>
                  </tr>
                ))}

                {filteredStudents.length === 0 && (
                  <tr>
                    <td
                      colSpan="11"
                      className="text-center py-6 text-slate-500"
                    >
                      No students found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>

          </div>
        </div>

      </div>
    </div>
  );
}