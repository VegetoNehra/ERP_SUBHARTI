import {
  Users,
  GraduationCap,
  Bell,
  BookOpen,
  UserPlus,
  ClipboardList,
  FileText,
  ChevronRight,
} from "lucide-react";

import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";

function AdminDashboard() {
  const navigate = useNavigate();
  const [notices, setNotices] = useState([]);
  const [stats, setStats] = useState({
    students: 0,
    faculty: 0,
    notices: 0,
  });
  const [statsLoading, setStatsLoading] = useState(true);

  // Fetch dashboard stats
  useEffect(() => {
    const fetchStats = async () => {
      try {
        setStatsLoading(true);
        const response = await axios.get(
          "http://localhost:5000/api/admin/dashboard-stats"
        );
        setStats(response.data.stats);
      } catch (error) {
        console.error("Error fetching stats:", error);
      } finally {
        setStatsLoading(false);
      }
    };

    fetchStats();
  }, []);

  // Fetch notices
  useEffect(() => {
    const fetchNotices = async () => {
      try {
        const response = await axios.get(
          "http://localhost:5000/api/admin/notices"
        );
        setNotices(response.data.notices);
      } catch (error) {
        console.error("Error fetching notices:", error);
      }
    };

    fetchNotices();
  }, []);

  const dashboardStats = [
    {
      title: "Students",
      value: stats.students,
      subtitle: "Registered Students",
      icon: Users,
      color: "text-blue-600",
      bg: "bg-blue-50",
    },
    {
      title: "Faculty",
      value: stats.faculty,
      subtitle: "Active Faculty",
      icon: GraduationCap,
      color: "text-emerald-600",
      bg: "bg-emerald-50",
    },
    {
      title: "Notices",
      value: stats.notices,
      subtitle: "Active Notices",
      icon: Bell,
      color: "text-orange-600",
      bg: "bg-orange-50",
    },
  ];

  const handleDelete = async (id) => {
    const confirmed = window.confirm("Delete this notice?");

    if (!confirmed) return;
    try {
      await axios.delete(
        `http://localhost:5000/api/admin/notices/${id}`
      );

      setNotices((prev) =>
        prev.filter((notice) => notice.id !== id)
      );
      alert("Notice deleted successfully!");
    } catch (error) {
      console.error("Error deleting notice:", error);
      alert("Failed to delete notice");
    }
  };

  return (
    <div className="min-h-screen w-full flex justify-center bg-slate-100 py-10 px-4 sm:px-6 lg:px-8 font-sans text-slate-900">
      <div className="max-w-7xl mx-auto space-y-10">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-[#0F2557]">
            Welcome, Administrator
          </h1>
          <p className="text-slate-500 mt-1">
            Manage students, notices, results and ERP operations.
          </p>
        </div>

        {/* Stats */}
        {statsLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {dashboardStats.map((stat) => (
              <div
                key={stat.title}
                className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm animate-pulse"
              >
                <div className="h-4 bg-slate-200 rounded w-20 mb-4"></div>
                <div className="h-8 bg-slate-200 rounded w-16 mb-2"></div>
                <div className="h-4 bg-slate-200 rounded w-32"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
          {dashboardStats.map((stat) => (
                    <AdminStatCard
                      key={stat.title}
                      {...stat}
                    />
            ))}
          </div>
        )}

        {/* Main Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Quick Actions */}
          <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
            <h2 className="text-xl font-bold text-slate-800 mb-6">
              Quick Actions
            </h2>

            <div className="grid sm:grid-cols-2 gap-4">
              <ActionCard
                icon={UserPlus}
                title="Register Student"
                onClick={() => navigate("/admin/register-student")}
              />

              <ActionCard
                icon={UserPlus}
                title="Register Faculty"
                onClick={() => navigate("/admin/register-faculty")}
              />

              <ActionCard
                icon={Bell}
                title="Create Notice"
                onClick={() => navigate("/admin/create-notice")}
              />

              <ActionCard
                icon={Users}
                title="Manage Students"
                onClick={() => navigate("/admin/manage-students")}
              />

              <ActionCard
                icon={GraduationCap}
                title="Manage Faculty"
                onClick={() => navigate("/admin/manage-faculty")}
              />

              <ActionCard
                icon={ClipboardList}
                title="Manage Results"
              />

              <ActionCard
                icon={FileText}
                title="Attendance Records"
              />
            </div>
          </div>

          {/* Notice Management */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4">
            <h2 className="text-xl font-bold mb-4">Notice Management</h2>

            <div className="space-y-3 max-h-[400px] overflow-y-auto">
              {notices.length === 0 ? (
                <p className="text-slate-500 text-sm py-4">No notices yet</p>
              ) : (
                notices.map((notice) => (
                  <div
                    key={notice.id}
                    className="border rounded-lg p-3 hover:bg-slate-50 transition"
                  >
                    <h3 className="font-semibold text-slate-800">
                      {notice.title}
                    </h3>
                    <p className="text-sm text-slate-600 mt-1 line-clamp-2">
                      {notice.content}
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      {new Date(notice.created_at).toLocaleDateString("en-IN")}
                    </p>

                    <div className="flex gap-2 mt-3">
                      <button
                        onClick={() => navigate(`/admin/edit-notice/${notice.id}`)}
                        className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 transition"
                      >
                        Edit
                      </button>

                      <button
                        onClick={() => handleDelete(notice.id)}
                        className="px-3 py-1 text-sm bg-red-600 text-white rounded hover:bg-red-700 transition"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function AdminStatCard({
  title,
  value,
  subtitle,
  icon: Icon,
  color,
  bg,
}) {
  return (
    <div className="
      bg-white
      rounded-3xl
      border border-slate-200
      p-7
      shadow-sm
      hover:shadow-xl
      hover:-translate-y-1
      transition-all
      duration-300
      cursor-default
    ">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs uppercase tracking-widest text-slate-500 font-semibold">
            {title}
          </p>

          <h3 className="text-4xl font-bold text-slate-800 mt-3">
            {value}
          </h3>

          <p className="text-sm text-slate-500 mt-2">
            {subtitle}
          </p>
        </div>

        <div
          className={`
            ${bg}
            p-4
            rounded-2xl
            shadow-sm
          `}
        >
          <Icon className={`w-7 h-7 ${color}`} />
        </div>
      </div>
    </div>
  );
}

function ActionCard({ title, icon: Icon, onClick }) {
  return (
    <button
      onClick={onClick}
      className="
        group
        flex
        items-center
        justify-between
        p-5
        rounded-2xl
        border
        border-slate-200
        bg-white
        hover:border-[#1E4DB7]
        hover:bg-blue-50
        hover:shadow-md
        transition-all
        duration-300
      "
    >
      <div className="flex items-center gap-4">
        <div className="bg-blue-100 p-3 rounded-xl">
          <Icon className="w-5 h-5 text-[#1E4DB7]" />
        </div>

        <span className="font-semibold text-slate-800">
          {title}
        </span>
      </div>

      <ChevronRight
        className="
          w-5
          h-5
          text-slate-400
          group-hover:text-[#1E4DB7]
          group-hover:translate-x-1
          transition-all
        "
      />
    </button>
  );
}

export default AdminDashboard;
