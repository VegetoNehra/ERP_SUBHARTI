import axios from "axios";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const CreateNotice = () => {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:5000/api/admin/create-notice", { title, content });
      alert("Notice created successfully!");
      navigate("/admin/dashboard"); // Redirect to the admin dashboard after successful creation
    } catch (error) {
      alert("Failed to create notice");
      console.error("Error creating notice:", error);
    }
  };

  return (
    <div className="min-h-[calc(100vh-96px)] bg-slate-100 flex items-center justify-center px-4 py-10">
        <div className="w-full max-w-3xl bg-white rounded-3xl overflow-hidden shadow-2xl border border-slate-200">

            <div className="bg-[#0F2557] px-8 py-8">
                <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                    Create Notice
                </h1>
            </div>
            
            <form onSubmit={handleSubmit}>
                <div  className="p-8 flex flex-col gap-4">
                    <label className="block mb-2 font-medium"> Title </label>
                    <input
                        type="text"
                        className="border border-gray-300 rounded-md p-2 w-full"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        placeholder="Enter notice title"
                        required
                        />
                    <label className="block mb-2 font-medium">
                    Content
                    </label>
                    <textarea
                        className="border border-gray-300 rounded-md p-2 w-full"    
                        placeholder="Enter notice content"
                        value={content}
                        onChange={(e) => setContent(e.target.value)}
                        required
                    />
                    <button
                    type="submit"
                    className="w-full bg-[#0F2557] text-white py-3 rounded-lg font-semibold hover:opacity-90 transition"
                    >
                    Send Notice
                    </button>
                </div>
            </form>
        </div>
    </div>
  );
};

export default CreateNotice;    