import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import { 
  CalendarCheck, 
  GraduationCap, 
  BookOpen, 
  Wallet, 
  Bell, 
  ChevronRight 
} from "lucide-react";

// --- Data Objects (Extracted to streamline the component body) ---
const METRICS = [
  { id: 1, title: "Attendance", value: "87%", subtitle: "Above minimum", icon: CalendarCheck, color: "text-blue-600", bg: "bg-blue-50" },
  { id: 2, title: "CGPA", value: "8.4", subtitle: "Good standing", icon: GraduationCap, color: "text-emerald-600", bg: "bg-emerald-50" },
  { id: 3, title: "Semester", value: "5th", subtitle: "Current semester", icon: BookOpen, color: "text-purple-600", bg: "bg-purple-50" },
  { id: 4, title: "Fee Status", value: "Paid", subtitle: "No dues", icon: Wallet, color: "text-indigo-600", bg: "bg-indigo-50" },
];


// --- Main Component ---
export default function StudentDashboard() {
  const [student, setStudent] = useState(null);
  const [notices, setNotices] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchStudent = async () => {
      try {
        const user = JSON.parse(localStorage.getItem("user"));

        const response = await axios.get(
          `http://localhost:5000/api/student/profile/${user.id}`
        );

        setStudent(response.data);
      } catch (error) {
        setError("Failed to fetch student data");
        console.error(error);
      }
    };

    fetchStudent();
  }, []);
  useEffect(() => {
    const fetchNotices = async () => {
      try {
        const response = await axios.get(
          "http://localhost:5000/api/student/notices"
        );

        setNotices(response.data.notices );
      } catch (error) {
        setError("Failed to fetch notices");
        console.error(error);
      }
    };

    fetchNotices();
  }, []);

  if (error) {
    return (
      <div className="flex items-center justify-center h-[70vh]">
        <p className="text-red-600 text-lg">
          {error}
        </p>
      </div>
    );
  }

  if (!student) {
    return (
      <div className="flex items-center justify-center h-[70vh]">
        <p className="text-slate-500 text-lg">
          Loading Student Profile...
        </p>
      </div>
    );
  }

  const metrics = [
    METRICS[0],
    METRICS[1],
    {
      ...METRICS[2],
      value: `${student.semester}`,
    },
    METRICS[3],
  ];


  const ACADEMIC_INFO = [
    { label: "Name", value: student.student_name || "-" },
    { label: "Enrollment No.", value: student.enrollment_number || "-" },
    { label: "Course", value: student.course || "-" },
    { label: "Branch", value: student.branch || "-" },
    { label: "10th Percentage", value: student.tenth_percentage || "-" },
    { label: "12th Percentage", value: student.twelfth_percentage || "-" },
    { label: "Father's Name", value: student.father_name || "-" },
    { label: "Mother's Name", value: student.mother_name || "-" },
    { label: "Email",value: student.email || "-"},
    { label: "Phone", value: student.phone || "-"}
  ];

  return (

    <div className="min-h-screen w-full flex justify-center bg-slate-50 py-10 px-4 sm:px-6 lg:px-8 font-sans text-slate-900">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header Section */}
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">
              Welcome back, {student?.student_name || "Loading..."}!
            </h1>
            <p className="text-slate-500 mt-1.5 font-medium">
              {student?.course || "Loading..."} • {student?.branch || "Loading..."} • Semester {student?.semester || "Loading..."}
            </p>
          </div>
          
        </header>

        {/* Metric Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {metrics   .map((metric) => (
            <MetricCard key={metric.id} {...metric} />
          ))}
        </div>

        {/* Lower Section Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Academic Details Panel */}
          <section className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200/60 p-6 sm:p-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-slate-800">Academic Details</h2>
              <button className="text-sm font-medium text-indigo-600 hover:text-indigo-700 transition-colors">
                Edit Profile
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-2">
              {ACADEMIC_INFO.map((info, index) => (
                <InfoRow key={index} label={info.label} value={info.value} />
              ))}
            </div>
          </section>

          {/* Notices Panel */}
          <section className="bg-white rounded-2xl shadow-sm border border-slate-200/60 p-6 sm:p-8 flex flex-col">
            <div className="flex items-center gap-2 mb-6">
              <Bell className="w-5 h-5 text-indigo-600" />
              <h2 className="text-xl font-bold text-slate-800">
                University Notices
              </h2>
            </div>

            <div className="space-y-1 flex-1 max-h-[400px] overflow-y-auto pr-2">
              {notices.map((notice) => (
                <Notice
                  key={notice.id}
                  title={notice.title}
                  content={notice.content}
                  created_at={notice.created_at}
                />
              ))}
            </div>
          </section>
          
        </div>

      </div>
    </div>
  );
}

// --- Subcomponents ---

function Notice({ title, content, created_at }) {
  return (
    <div className="group flex items-start gap-4 py-4 border-b border-slate-100">
      <div className="w-2 h-2 rounded-full bg-indigo-500 mt-2 shrink-0" />

      <div className="flex-1">
        <h3 className="font-semibold text-slate-700">
          {title}
        </h3>

        <p className="text-sm text-slate-500 mt-1">
          {content}
        </p>

        <p className="text-xs text-slate-400 mt-2">
          {new Date(created_at).toLocaleDateString("en-IN")}
        </p>
      </div>
    </div>
  );
}
function MetricCard({ title, value, subtitle, icon: Icon, color, bg }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200/60 p-6 shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-300 group">
      <div className="flex justify-between items-start mb-4">
        <p className="text-sm font-semibold tracking-wide text-slate-500 uppercase">
          {title}
        </p>
        <div className={`p-2.5 rounded-xl ${bg} ${color} transition-colors`}>
          <Icon className="w-5 h-5" strokeWidth={2.5} />
        </div>
      </div>
      <div>
        <h3 className="text-3xl font-extrabold text-slate-800 group-hover:text-indigo-600 transition-colors">
          {value}
        </h3>
        <p className="text-sm font-medium text-slate-500 mt-1">
          {subtitle}
        </p>
      </div>
    </div>
  );
}

function InfoRow({ label, value }) {
  return (
    <div className="flex flex-col justify-center py-3 border-b border-slate-100 last:border-0 sm:last:border-b-0 sm:[&:nth-last-child(2)]:border-0">
      <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
        {label}
      </span>
      <span className="font-medium text-slate-800">
        {value}
      </span>
    </div>
  );
}

