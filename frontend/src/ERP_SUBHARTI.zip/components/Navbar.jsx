// src/components/Navbar.jsx

import { Link, useLocation, useNavigate } from "react-router-dom";
import logo from "../assets/subharti_logo.webp";

function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const handleLogout = () => {
    localStorage.removeItem("user");
    navigate("/");
  };

const user = JSON.parse(localStorage.getItem("user"));

  return (
    <nav className="sticky top-0 z-50 bg-gray-400 border-b border-slate-200 shadow-sm">
      <div className="w-full px-8 lg:px-12">

        <div className="flex items-center justify-between h-[76px]">

          {/* Logo + Title */}
          <Link 
            to="/"
            className="flex items-center gap-4"
          >
            <img
              src={logo}
              alt="Subharti Logo"
              className="h-12 w-auto object-contain"
            />

            <div>
              <h1 className="text-xl font-bold text-[#0F2557] leading-none">
                Subharti ERP
              </h1>

              <p className="text-xs text-slate-500 mt-1">
                Student Management System
              </p>
            </div>
          </Link>

          {/* Navigation */}
          <div className="flex items-center gap-4">

            {!user ? (
            <>
              <Link
                to="/"
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  location.pathname === "/"
                    ? "bg-[#F0F4FF] text-[#1E4DB7]"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                Student Login
              </Link>

              <Link
                to="/admin"
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  location.pathname === "/admin"
                    ? "bg-[#F0F4FF] text-[#1E4DB7]"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                Admin Login
              </Link>
            </>
          ) : (
            <>
              <div className="text-right">
                <p className="text-xs text-slate-500 uppercase">
                  {user.role}
                </p>

                <p className="font-semibold text-slate-800">
                  {user.name}
                </p>
              </div>

              <button
                onClick={handleLogout}
                className="px-4 py-2 rounded-lg text-black font-medium hover:bg-red-600 transition"
              >
                Logout
              </button>
            </>
          )}
          </div>

        </div>

      </div>
    </nav>
  );
}

export default Navbar;